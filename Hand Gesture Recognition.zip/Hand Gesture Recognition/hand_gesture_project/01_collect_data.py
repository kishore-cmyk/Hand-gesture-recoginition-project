import warnings
warnings.filterwarnings("ignore", message="SymbolDatabase.GetPrototype() is deprecated")

import cv2
import mediapipe as mp
import numpy as np
import os

# Initialize MediaPipe Hands
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
hands = mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7)

def collect_gesture_data(gesture_name, num_samples=50):
    """
    Collect training data for a specific gesture
    Press 'c' to capture sample, 'q' to quit
    """
    # Create directory for this gesture
    os.makedirs(f'training_data/{gesture_name}', exist_ok=True)
    
    cap = cv2.VideoCapture(0)
    count = 0
    
    print(f"Collecting {num_samples} samples for '{gesture_name}' gesture")
    print("Show the gesture and press 'c' to capture. Press 'q' when done.")
    
    while count < num_samples:
        ret, frame = cap.read()
        if not ret:
            continue
            
        # Flip frame for mirror view
        frame = cv2.flip(frame, 1)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Process the frame
        results = hands.process(rgb_frame)
        
        # Draw hand landmarks if detected
        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
        
        # Display instructions
        cv2.putText(frame, f"Gesture: {gesture_name}", (10, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        cv2.putText(frame, f"Samples: {count}/{num_samples}", (10, 70), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv2.putText(frame, "Press 'c' to capture, 'q' to quit", (10, 110), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        
        cv2.imshow('Collect Gesture Data', frame)
        
        key = cv2.waitKey(1) & 0xFF
        
        if key == ord('c') and results.multi_hand_landmarks:
            # Extract landmarks
            landmarks = []
            for hand_landmarks in results.multi_hand_landmarks:
                for lm in hand_landmarks.landmark:
                    landmarks.extend([lm.x, lm.y, lm.z])
            
            # Save landmarks
            np.save(f'training_data/{gesture_name}/sample_{count}.npy', landmarks)
            count += 1
            print(f"Saved sample {count}/{num_samples}")
            
        elif key == ord('q'):
            break
    
    cap.release()
    cv2.destroyAllWindows()
    print(f"Finished collecting {count} samples for {gesture_name}")

if __name__ == "__main__":
    # Collect data for different gestures
    gestures = ["thumbs_up", "peace", "fist", "ok", "open_hand"]
    
    for gesture in gestures:
        collect_gesture_data(gesture, num_samples=50)
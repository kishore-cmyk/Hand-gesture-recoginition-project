import numpy as np
import os
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import pickle

def load_training_data():
    """Load all training data from the training_data folder"""
    X = []  # Features (landmarks)
    y = []  # Labels (gesture names)
    gesture_labels = []  # List of gesture names
    
    # Get all gesture folders
    gesture_folders = [f for f in os.listdir('training_data') 
                    if os.path.isdir(os.path.join('training_data', f))]
    
    if not gesture_folders:
        print("No training data found! Please run 01_collect_data.py first.")
        return None, None, None
    
    # Load data from each gesture folder
    for label, gesture_name in enumerate(gesture_folders):
        gesture_path = os.path.join('training_data', gesture_name)
        gesture_labels.append(gesture_name)
        
        # Load all samples for this gesture
        sample_files = [f for f in os.listdir(gesture_path) if f.endswith('.npy')]
        
        for sample_file in sample_files:
            sample_path = os.path.join(gesture_path, sample_file)
            landmarks = np.load(sample_path)
            X.append(landmarks)
            y.append(label)
    
    return np.array(X), np.array(y), gesture_labels

def train_gesture_model():
    """Train a machine learning model to recognize gestures"""
    print("Loading training data...")
    X, y, gesture_labels = load_training_data()
    
    if X is None:
        return
    
    print(f"Loaded {len(X)} samples for {len(gesture_labels)} gestures")
    print(f"Gestures: {gesture_labels}")
    
    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Train a Random Forest classifier
    print("Training model...")
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    # Check accuracy
    accuracy = model.score(X_test, y_test)
    print(f"Model accuracy: {accuracy:.2%}")
    
    # Save the model and labels
    model_data = {
        'model': model,
        'labels': gesture_labels,
        'accuracy': accuracy
    }
    
    with open('gesture_model.pkl', 'wb') as f:
        pickle.dump(model_data, f)
    
    print("Model saved as 'gesture_model.pkl'")
    return model_data

if __name__ == "__main__":
    train_gesture_model()
import warnings
warnings.filterwarnings("ignore", message="SymbolDatabase.GetPrototype() is deprecated")

import cv2
import mediapipe as mp
import numpy as np
import pickle
from collections import deque

class HandGestureRecognizer:
    def __init__(self):
        # Initialize MediaPipe Hands
        self.mp_hands = mp.solutions.hands
        self.mp_drawing = mp.solutions.drawing_utils
        self.hands = self.mp_hands.Hands(
            max_num_hands=1,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.7
        )
        
        # Load trained model
        try:
            with open('gesture_model.pkl', 'rb') as f:
                model_data = pickle.load(f)
                self.model = model_data['model']
                self.gesture_labels = model_data['labels']
                print(f"Loaded model for gestures: {self.gesture_labels}")
        except:
            print("No trained model found! Please run 02_train_model.py first.")
            self.model = None
            self.gesture_labels = []
        
        # For smoothing predictions
        self.prediction_history = deque(maxlen=15)
    
    def extract_landmarks(self, hand_landmarks):
        """Extract hand landmarks in the same format as training"""
        landmarks = []
        for lm in hand_landmarks.landmark:
            landmarks.extend([lm.x, lm.y, lm.z])
        return np.array(landmarks).reshape(1, -1)
    
    def recognize_gesture(self, frame):
        """Process frame and recognize gesture"""
        # Convert to RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.hands.process(rgb_frame)
        
        gesture_name = "No hand detected"
        confidence = 0
        
        if results.multi_hand_landmarks and self.model is not None:
            for hand_landmarks in results.multi_hand_landmarks:
                # Draw hand landmarks
                self.mp_drawing.draw_landmarks(
                    frame, hand_landmarks, self.mp_hands.HAND_CONNECTIONS)
                
                # Extract and predict landmarks
                landmarks = self.extract_landmarks(hand_landmarks)
                prediction = self.model.predict(landmarks)
                confidence = np.max(self.model.predict_proba(landmarks))
                
                current_gesture = self.gesture_labels[prediction[0]]
                self.prediction_history.append(current_gesture)
                
                # Use most frequent recent prediction (smoothing)
                if self.prediction_history:
                    gesture_name = max(set(self.prediction_history),  key=self.prediction_history.count)
        
        # Display results
        cv2.putText(frame, f"Gesture: {gesture_name}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        cv2.putText(frame, f"Confidence: {confidence:.2f}", (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        
        return frame, gesture_name, confidence

def main():
    """Main function to run gesture recognition"""
    recognizer = HandGestureRecognizer()
    
    if recognizer.model is None:
        return
    
    cap = cv2.VideoCapture(0)
    
    print("Starting gesture recognition. Press 'q' to quit.")
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
            
        # Flip frame for mirror view
        frame = cv2.flip(frame, 1)
        
        # Recognize gesture
        output_frame, gesture, confidence = recognizer.recognize_gesture(frame)
        
        # Display
        cv2.imshow('Hand Gesture Recognition', output_frame)
        
        # Exit on 'q' key
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
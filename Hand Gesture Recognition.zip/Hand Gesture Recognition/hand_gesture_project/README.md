# Hand Gesture Recognition Project

A beginner-friendly hand gesture recognition system using Python, OpenCV, and MediaPipe.

## How to Use

1. **Install requirements**: `pip install -r requirements.txt`

2. **Collect training data**: `python 01_collect_data.py`
   - Shows instructions for each gesture
   - Press 'c' to capture samples
   - Press 'q' to move to next gesture

3. **Train the model**: `python 02_train_model.py`
   - Automatically loads all collected data
   - Trains a machine learning model
   - Saves model to `gesture_model.pkl`

4. **Recognize gestures**: `python 03_recognize_gestures.py`
   - Opens webcam and shows real-time recognition
   - Press 'q' to quit

## Gestures to Collect

- thumbs_up 👍
- peace ✌️
- fist ✊
- ok 👌
- open_hand 🖐️

## Tips for Best Results

1. Use good lighting
2. Keep background consistent
3. Collect 50+ samples per gesture
4. Make distinct gestures